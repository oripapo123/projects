package tests;

import repairs.RepairMaterial;
import repairs.RepairMaterialInformation;
import repairs.RepairTool;
import repairs.RepairToolInformation;

public interface iWarehouse {
	boolean  orderTools(String orderedTools, int amountOrdered);
	boolean releaseTools(String releasedTools, int amountOrdered);
	boolean  orderMaterial(String orderedMaterials, int amountOrdered);
	boolean releaseMaterial(String releasedMaterials, int amountOrdered);
}