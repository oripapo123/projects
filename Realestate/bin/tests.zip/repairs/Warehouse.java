package repairs;
import tests.iWarehouse;


public class Warehouse implements iWarehouse {
	private RepairMaterial[] materials;
	private RepairTool[] tools;
	
	public Warehouse(RepairMaterial[] materials, RepairTool[] tools) {
		this.materials=materials;
		this.tools=tools;
	}
	
	public boolean  orderTools(String orderedTools, int amountOrdered){
		return false;
	}
	
	public boolean releaseTools(String releasedTools, int amountOrdered){
		return false;
	}
	
	public boolean  orderMaterial(String orderedMaterials, int amountOrdered){
		return false;
	}
	
	public boolean releaseMaterial(String releasedMaterials, int amountOrdered){
		return false;
	}
	
}
